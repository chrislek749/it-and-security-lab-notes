# Phishing triage - no coding

Goal: decide how to handle three fictional messages using email evidence. Best for SOC placements. All domains end in .example and no links should be opened. This is your own training lab, separate from Forage.

## Tasks
1. Read messages.txt and record sender, reply-to, requested action and any mismatch
2. Fill triage.csv: verdict (suspicious/uncertain/lower concern), evidence, missing context and next step
3. Write a 100-word user reply for the most suspicious message: explain how to report it without clicking or replying
4. Compare with ANSWERS.md and explain a false-positive risk

Success: three reasoned decisions, exact evidence, and a sensible escalation response. No need to identify every message as malicious. Sender authentication is one signal, not proof of safety.

After personal completion, possible SOC CV bullet: Reviewed three synthetic emails, documented sender and reply-to inconsistencies, and produced a phishing triage matrix and user-reporting guidance

This pack was prepared by AI. Your triage and response are still pending.
