# Worked reference - compare after your own review

P01: Suspicious. Urgency, password request, unapproved sender domain and different reply-to/link domain justify reporting and withholding interaction. Authentication passes relate to the sender's domain; they do not make it the employer's domain. Escalate via the established reporting channel.

P02: Uncertain, potentially high impact. An authenticated company sender could still be compromised. Verify the change through an established contact method and the normal payment-change process. Do not approve a payment or open an unknown attachment as part of this exercise. There is insufficient evidence to label it definitely fraudulent.

P03: Lower concern, not guaranteed safe. Expected context and no link/attachment reduce concern. Use the existing portal bookmark and verify the schedule there if needed.

Sample reply for P01: Please do not use the message's link or reply with your password. Report the email using the normal security reporting route. If you already entered a password, contact IT immediately through the known helpdesk details so they can review the account and guide the next steps. We will check whether this message came from an approved service.

Do not copy this as proof of your own analysis; explain which evidence led you to your decisions.
