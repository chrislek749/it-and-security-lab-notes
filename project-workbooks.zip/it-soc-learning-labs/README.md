# IT and SOC learning labs

A beginner portfolio of simulated security investigations, IT support exercises and a home media-server design.

## Project status and contributions

| Project | Available work | Status |
|---|---|---|
| Personal PC build | Owner confirms installing CPU, GPU, RAM and PSU | Hardware build completed; detailed build record pending |
| [Authentication lab](authentication-lab/LEARN_WITH_ME.md) | Synthetic data, Python analysis, CSV/JSON results, reference report, four passing tests | Reference implementation completed; learner investigation pending |
| [Phishing triage](phishing-triage/README.md) | Three synthetic messages, response template and worked answers | Learner review pending |
| [IT support](it-support/README.md) | Three fictional tickets, tracker and reference guidance | Learner responses pending |
| [Home media server](home-media-server/README.md) | Jellyfin setup and validation plan | Not installed; hardware/OS details pending |

The teaching materials, analysis code and reference answers were prepared with OpenAI Codex. They are not evidence that the owner independently wrote the tool or completed the investigations. Personal reports and reflections will be added as the exercises are completed.

All log events, accounts, email messages and support cases are fictional. No real incidents were investigated. No server was deployed by preparing this repository.

## Run the working lab

Python 3.10 or newer, standard library only:

```text
cd authentication-lab
python analyse.py
python -m unittest -v test_analyse.py
```

Expected: 24 events, 17 failures, 7 successes; rule triggers E009, E015 and E017. These are review signals, not proof of attacks. The tool rewrites only its local results directory. Four unit tests cover the sample, benign retry, time-window separation and account correlation.

## No-code route

Read the CSV/logs and record your decisions before viewing the reference answers. For each project retain your evidence, a short report and a reflection. See each project's guide for completion criteria.

## Limitations

The authentication rules use a small synthetic dataset and teaching thresholds. There is no SIEM deployment, production-scale performance measurement or measured false-positive rate. Home-server instructions are a plan awaiting the actual machine details.
