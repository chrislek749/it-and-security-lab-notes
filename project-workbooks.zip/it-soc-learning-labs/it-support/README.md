# IT support ticket lab - no coding

Goal: practise asking useful questions, distinguishing symptoms from causes and documenting a safe next step. Best for IT support placements; builds on your Nybble experience without inventing extra work there.

Open cases.txt and complete tickets.csv. For each case, record impact, questions, first diagnostic check, expected result and escalation criteria. These are tabletop cases, not machines you actually repaired. Compare with ANSWERS.md only after writing your own reasoning.

Deliverables: three completed case records and a one-page handover explaining what is known, what remains uncertain and who should act next. Record tests as proposed unless you actually perform them on your own test device.

After completion, possible CV bullet: Triaged three simulated IT support cases, documented diagnostic checks and escalation criteria, and created a structured ticket handover

Time: 45-60 minutes. No software installation needed. AI prepared the cases and worked answers; your responses are pending.
