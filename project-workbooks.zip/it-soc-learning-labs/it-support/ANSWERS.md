# Worked reference

T01: Check selected monitor input and cable connection before assuming a graphics-card fault. Ask when it last worked and what changed. Test an approved spare cable/monitor if authorised. Do not open a power supply or perform internal repairs as part of this beginner exercise. Escalate unresolved hardware faults with observed behaviour and test results. No root cause is yet established.

T02: Working intranet and a colleague's success make a general network outage less likely. Verify exact path, account and required group with the access owner. Obtain approved access before changes. Never grant broad Everyone permissions to bypass the error. Escalate to the access administrator with the approved request. No permission change has been performed.

T03: Low free storage and high memory use are clues, not proof of a cause. Ask about timing, applications and recent changes; protect unsaved work. Inspect application usage and storage categories before agreeing any cleanup. Do not delete files or disable security tools. Arrange a suitable time for changes, then compare the same operation before and after. No improvement percentage can be claimed without measurements.

Priorities depend on business impact and urgency, not the symptom alone. These cases affect one person each; ask about deadlines and service criticality before assigning a priority.
