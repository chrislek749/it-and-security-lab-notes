# Generated evidence summary

Synthetic training data only. AI-assisted analysis tool.

Events: 24; failures: 17; successes: 7

| Source IP | Failures | Successes | Distinct accounts |
|---|---:|---:|---:|
| 192.0.2.10 | 0 | 2 | 1 |
| 192.0.2.11 | 0 | 2 | 1 |
| 192.0.2.12 | 1 | 1 | 1 |
| 192.0.2.13 | 0 | 1 | 1 |
| 198.51.100.23 | 10 | 0 | 5 |
| 203.0.113.44 | 6 | 1 | 1 |

## First rule triggers

- MULTI_ACCOUNT_FAILURES: E009; evidence E005, E006, E007, E008, E009
- REPEATED_ACCOUNT_FAILURES: E015; evidence E011, E012, E013, E014, E015
- SUCCESS_AFTER_FAILURES: E017; evidence E011, E012, E013, E014, E015, E016, E017

Rules identify patterns requiring review, not confirmed attacks. Passwords are not logged, so the multi-account pattern cannot establish password spraying specifically.
This small demonstrator emits only the first alert per rule/source/account for the entire file. Production logic needs episode resets, larger-scale processing, identity context and validation.